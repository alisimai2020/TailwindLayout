package com.springsecurity.seurity.Entities;

public enum Role {
        USER,
        ADMIN
}
