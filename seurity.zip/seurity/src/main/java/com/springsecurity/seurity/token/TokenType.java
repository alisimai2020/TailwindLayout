package com.springsecurity.seurity.token;

public enum TokenType {
    BEARER
}
