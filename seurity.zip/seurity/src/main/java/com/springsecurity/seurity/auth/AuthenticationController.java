package com.springsecurity.seurity.auth;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {
    private final AuthenticationService service;

    @PostMapping("/register")
    public ResponseEntity<AuthenticationResponse> register(
        @ModelAttribute RegisterRequest register,
        @RequestPart MultipartFile imageFile
    ) {
        register.setImageFile(imageFile); 
    
        AuthenticationResponse response = service.register(register);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> authenticate(
        @RequestBody AuthenticationRequest authenticationRequest
    ) {
        return ResponseEntity.ok(service.authenticate(authenticationRequest));
    }
}
