package com.springsecurity.seurity.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.springsecurity.seurity.Entities.Role;
import com.springsecurity.seurity.Entities.User;
import com.springsecurity.seurity.repository.UserRepository;
import com.springsecurity.seurity.service.JWTService;
import com.springsecurity.seurity.token.Token;
import com.springsecurity.seurity.token.TokenRepository;
import com.springsecurity.seurity.token.TokenType;



@Service
@RequiredArgsConstructor
public class AuthenticationService {
  private final UserRepository repository;
    private final TokenRepository tokenRepository;

  private final PasswordEncoder passwordEncoder;
  private final JWTService jwtService;
  private final AuthenticationManager authenticationManager;
// Define the folder where images will be stored
private static final String IMAGE_UPLOAD_DIR = "src/main/resources/images/";


  public AuthenticationResponse register(RegisterRequest request) {
    var user = User.builder()
        .firstname(request.getFirstName())
        .lastname(request.getLastName())
        .email(request.getEmail())
        .password(passwordEncoder.encode(request.getPassword()))
        .role(Role.USER)
        .ImageFile(saveImage(request.getImageFile()))
        .build();
    var savedUser =  repository.save(user);
    var jwtToken = jwtService.generateToken(user);
   
    saveUsertoken(savedUser, jwtToken);
    return AuthenticationResponse.builder()
        .token(jwtToken)
        .build();
  }


  private String saveImage(MultipartFile imageFile) {
    String imageName = UUID.randomUUID().toString() + "_" + imageFile.getOriginalFilename();
    try {
        Path imagePath = Paths.get(IMAGE_UPLOAD_DIR, imageName);
        Files.copy(imageFile.getInputStream(), imagePath, StandardCopyOption.REPLACE_EXISTING);
        return imageName;
    } catch (IOException e) {
        // Handle the exception, e.g., log an error or throw a custom exception
        throw new RuntimeException("Failed to save the image");
    }
}




  private void saveUsertoken(User user, String jwtToken) {
    var token = Token.builder()

        .user(user)
        .token(jwtToken)
        .tokenType(TokenType.BEARER)
        .expired(false)
        .revoked(false)
       
       .build();

       tokenRepository.save(token);
  }

  public AuthenticationResponse authenticate(AuthenticationRequest request) {
    authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(
            request.getEmail(),
            request.getPassword() 
           
            

        )
    );
    var user = repository.findByEmail(request.getEmail())
        .orElseThrow();
        
    var jwtToken = jwtService.generateToken(user);
   saveUsertoken(user, jwtToken);
    return AuthenticationResponse.builder()
         .token(jwtToken)
        .build();
  }

  

  }

