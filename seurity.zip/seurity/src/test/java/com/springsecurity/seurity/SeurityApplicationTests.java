package com.springsecurity.seurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
